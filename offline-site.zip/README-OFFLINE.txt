OFFLINE COPY | frus-1989-92v15-assist

Extract the whole ZIP; keep its folders together. For full search, filtering, and
tables, start a local HTTP server from the extracted folder and open the address:

  macOS/Linux: python3 -m http.server 8000 --bind 127.0.0.1
  Windows:     py -m http.server 8000 --bind 127.0.0.1

Visit http://127.0.0.1:8000/ in your browser. Stop the server with Ctrl+C.
On locked-down computers, use an approved local static web server instead.
Double-clicking index.html may show the shell, but browsers often block local data
requests that way. You can browse the raw files in data/ directly if needed.

The site pages, local datasets, and available bundled documents are included.
Linked third-party records, archives, fonts, and cross-site links still require
network access; linked-only documents are not blank pages or missing ZIP files.
Keep external URLs for provenance. The public source site is https://therealjameswilson.github.io/frus-1989-92v15-assist/
